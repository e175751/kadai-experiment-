#!/bin/zsh
echo "引数の数 : $#"
echo "スクリプト名 : $0"
echo "第１引数 : $1"
echo "第２引数 : $2"
echo "引数一覧 : $*"
echo "引数一覧 : $@"
