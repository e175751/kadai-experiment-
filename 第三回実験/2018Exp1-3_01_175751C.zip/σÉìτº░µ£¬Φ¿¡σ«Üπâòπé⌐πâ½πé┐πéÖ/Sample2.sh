#!/bin/zsh
str1="University of the Ryukyus"
str2=\"University\ of\ the\ Ryukyus\"
echo str1=$str1
echo str2=$str2
str3\",\$,\@,\`,\^,\*,\?
str4=\(,\),\[,\],{,\},\<,\>
echo str3=$str3
echo str4=$str4