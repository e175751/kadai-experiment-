#!/bin/zsh

list=(175791 175792 175793 175794 175795)
a="${list[0]}"
echo a=$a
echo  ${list[2]}
#for num in $list
#do
 #    echo e$num@ie.u-ryukyu.ac.jp
#done