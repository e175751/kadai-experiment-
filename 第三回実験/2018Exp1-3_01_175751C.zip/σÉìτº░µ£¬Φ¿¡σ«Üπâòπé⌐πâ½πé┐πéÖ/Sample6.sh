#!/bin/zsh
n=0
while [[ n -lt 10 ]]
do
      n=$((n + 1))
      echo "n=$n"
done